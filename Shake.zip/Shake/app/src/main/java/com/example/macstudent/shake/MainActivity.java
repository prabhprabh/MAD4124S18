package com.example.macstudent.shake;

import android.content.Context;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.squareup.seismic.ShakeDetector;

public class MainActivity extends AppCompatActivity implements ShakeDetector.Listener{

    //global var if light is on or off
    boolean LightOn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //create variables
        SensorManager manager = (SensorManager) getSystemService(SENSOR_SERVICE);
        ShakeDetector detector = new ShakeDetector(this);
        detector.start(manager);

    }

    @Override
    public void hearShake() {
        Log.d("prabh","shake shake");
        Toast.makeText(this,"shaking",Toast.LENGTH_SHORT).show();


        CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);

        //turn on flash light
        //1- which cam front or back
        try {

            String cameraID = cameraManager.getCameraIdList()[0];   //0 is for back cam
            //turn on
            if(LightOn == false) {
                cameraManager.setTorchMode(cameraID, true);
                Log.d("prabh", "working");
                Toast.makeText(this, "flash On", Toast.LENGTH_SHORT).show();

                LightOn = true;
            }else{
                cameraManager.setTorchMode(cameraID,false);
                Log.d("prabh", "working");
                Toast.makeText(this, "flash Off", Toast.LENGTH_SHORT).show();
                LightOn = false;
            }
            //turn off
            //cameraManager.setTorchMode(cameraID,false);

        }catch (Exception e){

            Log.d("prabh","not working");
            Toast.makeText(this,"flash not working",Toast.LENGTH_SHORT).show();
        }



        //2- turn on flash

    }
}
