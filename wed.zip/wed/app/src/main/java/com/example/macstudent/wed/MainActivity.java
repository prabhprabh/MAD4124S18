package com.example.macstudent.wed;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {


    EditText et;
    // 1. Create a shared preferences variable
    SharedPreferences prefs;

    // 2. Setup shared preferences variable
    public static  final String PREFERENCES_NAME = "ABC";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et = (EditText) findViewById(R.id.editText);


        prefs = getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
    }

    public void saveData (View view){
        Log.d ("prabh","saveee");

        //to edit shared pref
        SharedPreferences.Editor prefEditor = prefs.edit();

        String editData = et.getText().toString();
        prefEditor.putString("name", editData);

        prefEditor.apply();
    }
    public void fetchData (View view){
        Log.d ("prabh","fetch");

        //get somethig outta shared pref
        String n = prefs.getString("name","");

        Log.d("prabh","got something: " + n);
    }
}
