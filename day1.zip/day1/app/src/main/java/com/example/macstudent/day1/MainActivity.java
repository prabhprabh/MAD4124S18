package com.example.macstudent.day1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.IOException;
import java.util.Iterator;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {
OkHttpClient client = new OkHttpClient();


//user interface
    TextView textViewMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initialize outlet
        textViewMain = (TextView) findViewById(R.id.textViewMain);
    }

    //action for button(click handler)
    public void pressed(View v){

       // option 1
      //  System.out.println('btn clicked');

        //option 2
        Log.d("Prabh","clicked!!!!!!!!!!!!");


        //tell the url
        String url = "https://api.coindesk.com/v1/bpi/historical/close.json?currency=BRL&start=2018-01-01&end=2018-01-10";
        Request request = new Request.Builder().url(url).build();


        //send requesty to internet nd wait for response
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                //what should happen if request fails
                Log.d("Prabh","error");
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Log.d("Prabh","successful");

                if (response.isSuccessful()) {
                    final String reply = response.body().string();

                    try {
                        //json object
                        JSONObject json = new JSONObject(reply);
                        JSONObject bpi =  json.getJSONObject("bpi");

                        String disclaimer = json.getString("disclaimer");
                        Log.d("prabh", (disclaimer));
                        Log.d("prabh", bpi.toString());


                        // iterate through the dictionary!

                        Iterator<String> iterator = bpi.keys();
                        while (iterator.hasNext()) {

                            String key = iterator.next();

                            double price = bpi.getDouble(key);

                            Log.d("prabh", "Key:");
                            Log.d("prabh", key);

                            Log.d("prabh", "Printing out the item:");
                            Log.d("prabh", Double.toString(price));
                        }

                        //parse json object

                        /*
                        // 2. parse the stuff inside the object
                        int userId = json.getInt("userId");
                        String title = json.getString("title");
                        boolean done = json.getBoolean("completed");



                        //do somethign with theses var
                        Log.d("prabh", Integer.toString(userId));
                        Log.d("prabh", (title));
                        Log.d("prabh", Boolean.toString(done));

                        //do some silly logic

                        if(done==false){
                            Log.d("prabh","system down");
                        }
                        if(userId == 1){
                            Log.d("prabh", title);
                        }
                        */
                    }
                    catch(Exception e){
                        Log.d("prabh","error");
                        e.printStackTrace();
                    }
                    //output json response to terminal
                    Log.d("prabh",reply);

                    //if u wanna output to ui
                    MainActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //ui nonsense here
                            textViewMain.setText(reply);
                        }
                    });

                }

            }
        });
        //do something with response
    }
}
